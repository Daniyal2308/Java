import java.util.Scanner;
//Известно, что X кг конфет стоит A рублей. Определить, сколько стоит 1 кг и Y кг этих же конфет.
class c33 {
    public static void main(String[] args)
    {
        System.out.println("Ведите массу");
        Scanner input = new Scanner(System.in);
        double weight = input.nextDouble();
        System.out.println("Ведите цена");
        double costs = input.nextDouble();
        double oneKilo = costs / weight;
        System.out.println("BEGIN_33");
        System.out.println("Цена за килограмм = " + oneKilo);
    }
}
