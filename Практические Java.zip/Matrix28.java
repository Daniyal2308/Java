import java.io.IOException;
//Дана матрица размера M × N. Найти минимальный среди максимальных элементов ее столбцов.
public class Matrix28 {
    public static void main(String[] args) throws IOException {

        // Создаем массив
        final int SizeX = 3; // Размер массива по X
        final int SizeY = 4; // Размер массива по Y

        int[][] A =
                {
                        {123, 23, 45, 44},
                        {12, 40, 44, 20},
                        {222, 56, 42, 34}
                };

        // Находим минимальные элементы
        for (int i = 0; i < SizeX; i++)
        {
            int minVal = A[i][0];
            for (int j = 0; j < SizeY; j++)
            {
                if (A[i][j] < minVal)
                {
                    minVal = A[i][j];
                }
            }
            System.out.print("Min [");
            System.out.print(i);
            System.out.print("] = ");
            System.out.print(minVal);
            System.out.print("\r\n");
        }

        byte ch;
        ch = Byte.parseByte(ConsoleInput.readToWhiteSpace(true));

    }






    public static final class ConsoleInput
    {
        private static boolean goodLastRead = false;
        public static boolean lastReadWasGood()
        {
            return goodLastRead;
        }

        public static String readToWhiteSpace(boolean skipLeadingWhiteSpace) throws IOException {
            String input = "";
            char nextChar;
            while (Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                //accumulate leading white space if skipLeadingWhiteSpace is false:
                if (!skipLeadingWhiteSpace)
                {
                    input += nextChar;
                }
            }
            //the first non white space character:
            input += nextChar;

            //accumulate characters until white space is reached:
            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
            }

            goodLastRead = input.length() > 0;
            return input;
        }

        public static String scanfRead() throws IOException {
            return scanfRead(null, -1);
        }

        public static String scanfRead(String unwantedSequence) throws IOException {
            return scanfRead(unwantedSequence, -1);
        }

        public static String scanfRead(String unwantedSequence, int maxFieldLength) throws IOException {
            String input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
                {
                    if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
                    {
                        //ignore all subsequent white space:
                        while (Character.isWhitespace(nextChar = (char)System.in.read()))
                        {
                        }
                    }
                    else
                    {
                        //ensure each character matches the expected character in the sequence:
                        nextChar = (char)System.in.read();
                        if (nextChar != unwantedSequence.charAt(charIndex))
                            return null;
                    }
                }

                input = (new Character(nextChar)).toString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
                if (maxFieldLength == input.length())
                    return input;
            }

            return input;
        }
    }

}
