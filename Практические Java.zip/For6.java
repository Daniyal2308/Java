
import java.util.Scanner;
public class For6 {
    //Дано вещественное число A и целое число N (> 0). Используя один цикл, вывести все целые степени числа
    // A от 1 до N.
    public static void main(String[] args)  {
                Scanner in = new Scanner(System.in);

                System.out.print("a=");
                double a = in.nextDouble();
                System.out.print("n=");
                int n = in.nextInt();

                int result = 1;
                for (int i = 1; i <= n; i++) {
                    result *= a;
                    System.out.println(result);
                }
                in.close();
            }
        }


