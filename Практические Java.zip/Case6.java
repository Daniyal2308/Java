
//Единицы длины пронумерованы следующим образом: 1 — дециметр, 2 — километр, 3 — метр, 4 — миллиметр, 5 — сантиметр.
// Дан номер единицы длины (целое число в диапазоне 1–5) и длина отрезка в этих единицах (вещественное число).
// Найти длину отрезка в метрах.

import java.util.Scanner;

class case6 {
    public static void main(String[] args) throws java.lang.Exception {
        Scanner inputAnswer = new Scanner(System.in);

        System.out.print("Введите номер единицы длины: 1 — дециметр, 2 — километр, 3 — метр, 4 — миллиметр, 5 — сантиметр" + " ");
        int k = inputAnswer.nextInt();

        System.out.print("Введите ддлину отрезка: ");
        double m = inputAnswer.nextDouble();

        switch (k) {
            case 1:
                double c = m / 10;
                System.out.print("Равно: " + c + "м");
                break;

            case 2:
                double d = m * 1000;
                System.out.print("Равно: " + d + " м");
                break;

            case 3:
                double e = m;
                System.out.print("Равно: " + e + " м");
                break;

            case 4:
                double f = m / 1000;
                System.out.print("Равно: " + f + " м");
                break;

            case 5:
                double g = m / 100;
                System.out.print("Равно: " + g + " м");
                break;
            default:
                System.out.println("Ошибка! необходимо было ввести число от 1 до 5");
        }
    }
}
