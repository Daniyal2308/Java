import java.io.IOException;
//Спортсмен-лыжник начал тренировки, пробежав в первый день 10 км.
// Каждый следующий день он увеличивал длину пробега на P процентов от пробега предыдущего дня
// (P — вещественное, 0 < P < 50). По данному P определить, после какого дня суммарный пробег лыжника за
//все дни превысит 200 км, и вывести найденное количество дней K (целое) и суммарный пробег S (вещественное число).
public class While16 {
    public static void main(String[] args) throws IOException {

        float p;
        System.out.print("P:");
        p = Float.parseFloat(ConsoleInput.readToWhiteSpace(true));
        int k = 1;
        float d = 10F;
        float s = 10F;
        while (s <= 200F)
        {
            ++k;
            d += d * p / 100;
            s += d;
        }
        System.out.print("Кол-во дней k:");
        System.out.print(k);
        System.out.print("\n");
        System.out.print("Суммарный пробег S:");
        System.out.print(s);

    }



    public static final class ConsoleInput
    {
        private static boolean goodLastRead = false;
        public static boolean lastReadWasGood()
        {
            return goodLastRead;
        }

        public static String readToWhiteSpace(boolean skipLeadingWhiteSpace) throws IOException {
            String input = "";
            char nextChar;
            while (Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                //accumulate leading white space if skipLeadingWhiteSpace is false:
                if (!skipLeadingWhiteSpace)
                {
                    input += nextChar;
                }
            }
            //the first non white space character:
            input += nextChar;

            //accumulate characters until white space is reached:
            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
            }

            goodLastRead = input.length() > 0;
            return input;
        }

        public static String scanfRead() throws IOException {
            return scanfRead(null, -1);
        }

        public static String scanfRead(String unwantedSequence) throws IOException {
            return scanfRead(unwantedSequence, -1);
        }

        public static String scanfRead(String unwantedSequence, int maxFieldLength) throws IOException {
            String input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
                {
                    if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
                    {
                        //ignore all subsequent white space:
                        while (Character.isWhitespace(nextChar = (char)System.in.read()))
                        {
                        }
                    }
                    else
                    {
                        //ensure each character matches the expected character in the sequence:
                        nextChar = (char)System.in.read();
                        if (nextChar != unwantedSequence.charAt(charIndex))
                            return null;
                    }
                }

                input = (new Character(nextChar)).toString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
                if (maxFieldLength == input.length())
                    return input;
            }

            return input;
        }
    }

}
