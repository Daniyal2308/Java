import java.util.Scanner;
//Дана целочисленная матрица размера M × N. Найти номер первого
//из ее столбцов, содержащих только нечетные числа. Если таких столбцов нет, то вывести 0.
public class Matrix35
{

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Введите M (количество строк): ");
        int M = input.nextInt();
        System.out.print("Введите N (количество столбцов): ");
        int N = input.nextInt();
        int[][] A = new int[M][N];
        System.out.print("Исходная матрица:");
        for (int i = 0; i < A.length; i++) {
            System.out.println();
            for (int j = 0; j < A[i].length; j++) {
                A[i][j] = 10 + (int) (Math.random() * 99);
                System.out.print(A[i][j] + " ");
            }
        }

        int fl = 0, jj = -1;
        for (int j = 0; j < N; j++) {
            for (int i = 0; i < M; i++) {
                if (A[i][j] % 2 != 0) fl++;
            }
            if (fl == M) {
                jj = j + 1;
                break;
            } else fl = 0;
        }
        System.out.println();
        if (jj == -1) System.out.println("0");
        else System.out.println("Номер первого столбца, содержащего только нечётные числа: " + jj);
    }

}
