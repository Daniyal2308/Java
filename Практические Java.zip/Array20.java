import java.io.IOException;
//Дан массив размера N и целые числа K и L (1 ≤ K ≤ L ≤ N).
// Найти сумму элементов массива с номерами от K до L включительно.
public class Array20
{
    public static void main(String[] args) throws IOException {
        int[] a = new int[10];
        int n;
        int k;
        int l;

        System.out.print("N: ");
        n = Integer.parseInt(ConsoleInput.readToWhiteSpace(true));
        System.out.print("K: ");
        k = Integer.parseInt(ConsoleInput.readToWhiteSpace(true));
        System.out.print("L: ");
        l = Integer.parseInt(ConsoleInput.readToWhiteSpace(true));

        int i;
        for (i = 0; i < n; ++i)
        {
            System.out.print("a[");
            System.out.print(i + 1);
            System.out.print("] :");
            a[i] = Integer.parseInt(ConsoleInput.readToWhiteSpace(true));
        }

        int sum = 0;
        for (i = 0; i < k - 1; ++i)
        {
            sum += a[i];
        }
        for (i = l; i < n; ++i)
        {
            sum += a[i];
        }

        System.out.print((float)sum / (float)(k - 1 + (n - l)));


    }




    public static final class ConsoleInput
    {
        private static boolean goodLastRead = false;
        public static boolean lastReadWasGood()
        {
            return goodLastRead;
        }

        public static String readToWhiteSpace(boolean skipLeadingWhiteSpace) throws IOException {
            String input = "";
            char nextChar;
            while (Character.isWhitespace(nextChar = (char)System.in.read()))
            {

                if (!skipLeadingWhiteSpace)
                {
                    input += nextChar;
                }
            }

            input += nextChar;


            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
            }

            goodLastRead = input.length() > 0;
            return input;
        }

        public static String scanfRead() throws IOException {
            return scanfRead(null, -1);
        }

        public static String scanfRead(String unwantedSequence) throws IOException {
            return scanfRead(unwantedSequence, -1);
        }

        public static String scanfRead(String unwantedSequence, int maxFieldLength) throws IOException {
            String input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
                {
                    if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
                    {

                        while (Character.isWhitespace(nextChar = (char)System.in.read()))
                        {
                        }
                    }
                    else
                    {

                        nextChar = (char)System.in.read();
                        if (nextChar != unwantedSequence.charAt(charIndex))
                            return null;
                    }
                }

                input = (new Character(nextChar)).toString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
                if (maxFieldLength == input.length())
                    return input;
            }

            return input;
        }
    }

}
