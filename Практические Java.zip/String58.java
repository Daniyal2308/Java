public class String58 {
    //Дана строка, содержащая полное имя файла, то есть имя диска,список каталогов (путь),
    // собственно имя и расширение. Выделить из этой строки имя файла (без расширения).
    public static void main(String[] args) {
        String S = "\"Z:\\Программирование\\Разработка мобильных приложений\\Аюбов\\Практическая работа 7.txt\"";
        int num=92;
        int pos=S.lastIndexOf((char) num);
        S=S.substring(pos+1,S.length()-1);
        pos=S.lastIndexOf('.');
        S=S.substring(0,pos);
        System.out.println(S);
    }
}

