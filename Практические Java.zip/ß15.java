import java.io.IOException;
//Дана площадь S круга. Найти его диаметр D и длину L окружности,ограничивающей этот круг, учитывая,
// что L = 2·π·R, S = π·R^2.В качестве значения π использовать 3.14.
public class с15 {
    public static void main(String[] args) throws IOException {
        float S = 0;
        System.out.print("S:");
        String tempVar = ConsoleInput.scanfRead();
        if (tempVar != null)
        {
            S = Float.parseFloat(tempVar);
        }

        double D = Math.sqrt((4 * S) / 3.14);
        System.out.printf("D:%f\n",D);

        float L = (float) (3.14 * D);
        System.out.printf("L:%f\n",L);


    }



    public static final class ConsoleInput
    {
        private static boolean goodLastRead = false;
        public static boolean lastReadWasGood()
        {
            return goodLastRead;
        }

        public static String readToWhiteSpace(boolean skipLeadingWhiteSpace) throws IOException {
            String input = "";
            char nextChar;
            while (Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                //accumulate leading white space if skipLeadingWhiteSpace is false:
                if (!skipLeadingWhiteSpace)
                {
                    input += nextChar;
                }
            }
            //the first non white space character:
            input += nextChar;

            //accumulate characters until white space is reached:
            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
            }

            goodLastRead = input.length() > 0;
            return input;
        }

        public static String scanfRead() throws IOException {
            return scanfRead(null, -1);
        }

        public static String scanfRead(String unwantedSequence) throws IOException {
            return scanfRead(unwantedSequence, -1);
        }

        public static String scanfRead(String unwantedSequence, int maxFieldLength) throws IOException {
            String input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
                {
                    if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
                    {
                        //ignore all subsequent white space:
                        while (Character.isWhitespace(nextChar = (char)System.in.read()))
                        {
                        }
                    }
                    else
                    {
                        //ensure each character matches the expected character in the sequence:
                        nextChar = (char)System.in.read();
                        if (nextChar != unwantedSequence.charAt(charIndex))
                            return null;
                    }
                }

                input = (new Character(nextChar)).toString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
                if (maxFieldLength == input.length())
                    return input;
            }

            return input;
        }
    }

}
