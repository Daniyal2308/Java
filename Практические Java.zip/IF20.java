// На числовой оси расположены три точки: A, B, C. Определить, какая из двух последних точек (B или C)
// расположена ближе к A, и вывести эту точку и ее расстояние от точки A.

import java.util.Scanner;

class if20 {
    public static void main(String[] args) throws java.lang.Exception {
        Scanner inputAnswer = new Scanner(System.in);

        System.out.print("Введите координаты A: ");
        int a = inputAnswer.nextInt();
        System.out.print("Введите координаты B: ");
        int b = inputAnswer.nextInt();
        System.out.print("Введите координаты C: ");
        int c = inputAnswer.nextInt();

        int e = a - b;
        if (e < 0)
            e = (a - b) * -1;
        else
            e = a - b;

        int f = a - c;
        if (f < 0)
            f = (a - c) * -1;
        else
            f = a - c;

        if (e < f) System.out.print("Точка B=" + b + " ближе к точке A, находится на расстоянии " + e);
        else if (e > f) System.out.print("Точка C=" + c + " ближе к точке A, находится на расстоянии " + f);
        else
            System.out.print("Точка C=" + c + " и точка B=" + b + " находятся на одинаковом расстоянии к точке A " + e);

    }
}
