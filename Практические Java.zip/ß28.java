import java.io.IOException;
//. Дано число A. Вычислить A 15, используя две вспомогательные переменные и пять операций умножения.
// Для этого последовательно находить A^2, A^3, A^5, A^10, A^15. Вывести все найденные степени числа A.
public class с28 {
    public static void main(String[] args) throws IOException {
        float A = 0;
        System.out.print("A:");
        String tempVar = ConsoleInput.scanfRead();
        if (tempVar != null)
        {
            A = Float.parseFloat(tempVar);
        }

        float temp1A;
        float temp2A;

        temp1A = A * A;
        System.out.printf("A^2:%f\n",temp1A);

        temp2A = temp1A * A;
        System.out.printf("A^3:%f\n",temp2A);

        temp1A = temp1A * temp2A;
        System.out.printf("A^5:%f\n",temp1A);

        temp2A = temp1A * temp1A;
        System.out.printf("A^10:%f\n",temp2A);

        temp1A = temp2A * temp1A;
        System.out.printf("A^15:%f\n",temp1A);

       
    }





    public static final class ConsoleInput
    {
        private static boolean goodLastRead = false;
        public static boolean lastReadWasGood()
        {
            return goodLastRead;
        }

        public static String readToWhiteSpace(boolean skipLeadingWhiteSpace) throws IOException {
            String input = "";
            char nextChar;
            while (Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                //accumulate leading white space if skipLeadingWhiteSpace is false:
                if (!skipLeadingWhiteSpace)
                {
                    input += nextChar;
                }
            }
            //the first non white space character:
            input += nextChar;

            //accumulate characters until white space is reached:
            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
            }

            goodLastRead = input.length() > 0;
            return input;
        }

        public static String scanfRead() throws IOException {
            return scanfRead(null, -1);
        }

        public static String scanfRead(String unwantedSequence) throws IOException {
            return scanfRead(unwantedSequence, -1);
        }

        public static String scanfRead(String unwantedSequence, int maxFieldLength) throws IOException {
            String input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
                {
                    if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
                    {
                        //ignore all subsequent white space:
                        while (Character.isWhitespace(nextChar = (char)System.in.read()))
                        {
                        }
                    }
                    else
                    {
                        //ensure each character matches the expected character in the sequence:
                        nextChar = (char)System.in.read();
                        if (nextChar != unwantedSequence.charAt(charIndex))
                            return null;
                    }
                }

                input = (new Character(nextChar)).toString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
                if (maxFieldLength == input.length())
                    return input;
            }

            return input;
        }
    }

}
