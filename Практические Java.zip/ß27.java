public class с27 {
    //Дано число A. Вычислить A^8, используя вспомогательную переменную и три операции умножения.
    // Для этого последовательно находить A^2, A^4, A^8. Вывести все найденные степени числа A.
    public static void main(String[] args)
    {
        int a = 2;
        int tmp = a * a;
        System.out.println("BEGIN_27");
        System.out.println("A = " + a);
        System.out.println("A2 = " + tmp);
        tmp *= tmp;
        System.out.println("A4 = " + tmp);
        tmp *= tmp;
        System.out.println("A8 = " + tmp);
    }
}
