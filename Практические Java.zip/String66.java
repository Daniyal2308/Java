import java.util.*;
//Дана строка-предложение. Зашифровать ее, поместив вначале все символы, расположенные на четных позициях строки,
// а затем, в обратном порядке, все символы, расположенные на нечетных позициях
// (например, строка «Программа» превратится в «ргамамроП»).
public class String66{
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();
        StringBuilder revers = new StringBuilder();
        System.out.println("Введите строку: ");
        String s = new Scanner(System.in).nextLine();
        for (
                int i = 0; i < s.length(); i++) {
            if (i % 2 != 0) {
                sb.append(s.charAt(i));
            } else {
                revers.insert(0, s.charAt(i));
            }
        }

        System.out.printf("%1$s%2$s" + "\r\n", sb, revers);
    }
}
