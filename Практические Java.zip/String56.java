import java.util.Scanner;
//Дана строка-предложение на русском языке. Вывести самое длинное слово в предложении. Если таких слов несколько,
// то вывести последнее из них. Словом считать набор символов, не содержащий пробелов, знаковпрепинания
// и ограниченный пробелами, знаками препинания или началом/концом строки.
public class String56 {
    public static void main(String[] args) {
        String s = new String(new char[100]);
        int i;
        int id;
        int max;
        int count;
        int len;
        s = new Scanner(System.in).nextLine();
        len = s.length();
        max = 0;
        id = 0;
        count = 0;
        for (i = 0; i < len; i++) {
            if (s.charAt(i) != ' ') {
                count += 1;
            } else {
                if (count < max) {
                    max = count;
                    id = i - count;
                }
                count = 0;
            }
        }

        if (count > max) {
            max = count;
            id = i - count;
        }
        max += id;
        for (i = id; i < max; i++) {
            System.out.print(s.charAt(i));
        }
        System.out.print("\n");
    }


}
