import java.io.IOException;
//Дан массив размера N. Найти два соседних элемента, сумма которых
//максимальна, и вывести эти элементы в порядке возрастания их индексов.
public class Array41 {
    public static void main(String[] args)
     {
        int N = 0;
        int i;
        int c;
        int max;
        System.out.print("Введите массив N=");
         try {
             N = Integer.parseInt(ConsoleInput.readToWhiteSpace(true));
         } catch (IOException e) {
             e.printStackTrace();
         }
         float[] a = new float[N];
        for (i = 0;i < N;i++)
        {
            System.out.print(" Введите  элемент массива=");
            try {
                a[i] = Float.parseFloat(ConsoleInput.readToWhiteSpace(true));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        max = (int) (a[1] + a[2]);
        c = 1;
        for (i = 2;i < N - 1;i++)
        {
            if (a[i] + a[i + 1] > max)
            {
                c = i;
                max = (int) (a[i] + a[i + 1]);
            }
        }
        System.out.print("\n max element massiva=");
        System.out.print(a[c]);
        System.out.print(" and ");
        System.out.print(a[c + 1]);
        getch();
    }







    private static void getch() {
    }


    public static final class ConsoleInput
    {
        private static boolean goodLastRead = false;
        public static boolean lastReadWasGood()
        {
            return goodLastRead;
        }

        public static String readToWhiteSpace(boolean skipLeadingWhiteSpace) throws IOException {
            String input = "";
            char nextChar;
            while (Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                //accumulate leading white space if skipLeadingWhiteSpace is false:
                if (!skipLeadingWhiteSpace)
                {
                    input += nextChar;
                }
            }
            //the first non white space character:
            input += nextChar;

            //accumulate characters until white space is reached:
            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
            }

            goodLastRead = input.length() > 0;
            return input;
        }

        public static String scanfRead() throws IOException {
            return scanfRead(null, -1);
        }

        public static String scanfRead(String unwantedSequence) throws IOException {
            return scanfRead(unwantedSequence, -1);
        }

        public static String scanfRead(String unwantedSequence, int maxFieldLength) throws IOException {
            String input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
                {
                    if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
                    {
                        //ignore all subsequent white space:
                        while (Character.isWhitespace(nextChar = (char)System.in.read()))
                        {
                        }
                    }
                    else
                    {
                        //ensure each character matches the expected character in the sequence:
                        nextChar = (char)System.in.read();
                        if (nextChar != unwantedSequence.charAt(charIndex))
                            return null;
                    }
                }

                input = (new Character(nextChar)).toString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
                if (maxFieldLength == input.length())
                    return input;
            }

            return input;
        }
    }

}
