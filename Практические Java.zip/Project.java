public class Project {

    public static void main(String[] args)
    {
        int D, C;
        int a = 200;
        long b = -20;
        final double fin =  20.5;
        double f = 25.025;
        double myf = 33.475;
        String s = "F";
        double c = a - myf;
        long d = b + 2;
        System.out.println(s);
        System.out.println(d);
        System.out.println(c);
    }
}

