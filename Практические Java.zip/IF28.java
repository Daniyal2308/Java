import java.io.IOException;

public class IF28 {
    //Дан номер года (положительное целое число). Определить количество дней в этом году, учитывая,
    // что обычный год насчитывает 365 дней, а високосный — 366 дней. Високосным считается год,
    // делящийся на 4, зa исключением тех годов, которые делятся на 100 и не делятся на 400
    //(например, годы 300, 1300 и 1900 не являются високосными, а 1200 и 2000 — являются).
    public static void main(String[] args) throws IOException {


        int year;
        System.out.print("Введите номер года (положительное целое число): ");
        year = Integer.parseInt(ConsoleInput.readToWhiteSpace(true));
        int days = (year % 400 == 0 || year % 4 == 0 && year % 100 != 0) ? 366 : 365;

        System.out.print("Количество дней в этом году ");
        System.out.print(days);
        System.out.print("\n");





    }
    public static final class ConsoleInput
    {
        private static boolean goodLastRead = false;
        public static boolean lastReadWasGood()
        {
            return goodLastRead;
        }

        public static String readToWhiteSpace(boolean skipLeadingWhiteSpace) throws IOException {
            String input = "";
            char nextChar;
            while (Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                //накапливать начальные пробелы, если skipLeadingWhiteSpace имеет значение false:
                if (!skipLeadingWhiteSpace)
                {
                    input += nextChar;
                }
            }
            //первый непробельный символ
            input += nextChar;

            //накапливать символы до тех пор, пока не будет достигнут пробел
            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
            }

            goodLastRead = input.length() > 0;
            return input;
        }

        public static String scanfRead() throws IOException {
            return scanfRead(null, -1);
        }

        public static String scanfRead(String unwantedSequence) throws IOException {
            return scanfRead(unwantedSequence, -1);
        }

        public static String scanfRead(String unwantedSequence, int maxFieldLength) throws IOException {
            String input = "";

            char nextChar;
            if (unwantedSequence != null)
            {
                nextChar = '\0';
                for (int charIndex = 0; charIndex < unwantedSequence.length(); charIndex++)
                {
                    if (Character.isWhitespace(unwantedSequence.charAt(charIndex)))
                    {
                        //игнорировать все последующие пробелы:
                        while (Character.isWhitespace(nextChar = (char)System.in.read()))
                        {
                        }
                    }
                    else
                    {
                        //убедитесь, что каждый символ соответствует ожидаемому символу в последовательности:
                        nextChar = (char)System.in.read();
                        if (nextChar != unwantedSequence.charAt(charIndex))
                            return null;
                    }
                }

                input = (new Character(nextChar)).toString();
                if (maxFieldLength == 1)
                    return input;
            }

            while (!Character.isWhitespace(nextChar = (char)System.in.read()))
            {
                input += nextChar;
                if (maxFieldLength == input.length())
                    return input;
            }

            return input;
        }
    }

}
