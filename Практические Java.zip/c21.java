
    import java.util.Scanner;
//Даны координаты трех вершин треугольника: (x1, y1), (x2, y2), (x3, y3).
//Найти его периметр и площадь, используя формулу для расстояния между двумя точками на плоскости (см. задание Begin20).
// Для нахождения площади треугольника со сторонами a, b, c использовать формулу Герона:S =√p·(p − a)·(p − b)·(p − c),
// где p = (a + b + c)/2 — полупериметр.
    public class c21 {
        public static void main(String[] args)
        {
            Scanner input = new Scanner(System.in);
            System.out.println("Ведите Ax");
            int Ax = input.nextInt();
            System.out.println("Ведите Ay");
            int Ay = input.nextInt();
            System.out.println("Ведите Bx");
            int Bx = input.nextInt();
            System.out.println("Ведите By");
            int By = input.nextInt();
            System.out.println("Ведите Cx");
            int Cx = input.nextInt();
            System.out.println("Ведите Cy");
            int Cy = input.nextInt();
            double side1 = SideLen(Ax, Ay, Bx, By);
            double side2 = SideLen(Ax, Ay, Cx, Cy);
            double side3 = SideLen(Bx, By, Cx, Cy);
            double perim = (side1 + side2 + side3) /2;
            double square = Math.sqrt(perim * (perim-side1) * (perim-side2) * (perim-side3));
            System.out.println("BEGIN_21");
            System.out.println("Треугольник: Периметр=" + perim + ", Площадь=" + square);
        }

        public static double SideLen(int x1, int y1, int x2, int y2)
        {
            return Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1,2));
        }
    }

